# link-config
# Download config http injector, kpn tunnel revolution, kpn tunnel ultimate, script, windows, aplikadi, vedio, musik
# Install In Termux:
# $ pkg install git
# $ git clone https://github.com/Rusmana-ID/link-config
# $ cd link-config
# $ sh requests.sh
# $ sh link-config.sh

